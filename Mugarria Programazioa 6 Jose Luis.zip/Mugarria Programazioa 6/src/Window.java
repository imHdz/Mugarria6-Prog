
import DBconection.DBconection;
import DBconsults.DBconsults;
import model.Picture;
import org.jdesktop.swingx.JXDatePicker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.SimpleDateFormat;
import java.util.List;

public class Window extends JFrame {
    private JComboBox<String> photographerComboBox;
    private JXDatePicker datePicker;
    private JList<String> pictureList;
    private ImageIcon pictureImage;
    private  JLabel imageLabel;
    List<Picture> pictures;


    public Window(){
        setTitle("Photography");
        setLayout(new GridLayout(2,2));
        setPreferredSize(new Dimension(800, 600));
        this.pack();

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        photographerComboBox = new JComboBox<>();
        datePicker = new JXDatePicker();
        pictureList = new JList<>();
        imageLabel = new JLabel();



        JPanel photographerPanel = new JPanel();
        photographerComboBox.setPreferredSize(new Dimension(200,40));
        photographerComboBox.addItem(null);
        photographerComboBox.addActionListener(e -> loadPictureList((String) photographerComboBox.getSelectedItem()));
        this.loadPhotographersComboBox();

        photographerPanel.add(new JLabel("Photographer: "));
        photographerPanel.add(photographerComboBox);


        JPanel datePanel = new JPanel();
        datePanel.add(new JLabel("Photos after: "));
        datePicker.addActionListener(e -> loadPictureList((String) photographerComboBox.getSelectedItem()));
        datePanel.add(datePicker);


        JScrollPane pictureScrollPanel = new JScrollPane(pictureList);
        pictureScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        pictureList.addMouseListener(new MouseAdapter() {

            @Override
            public void mouseClicked(MouseEvent e) {
                if(e.getClickCount() ==  2){
                    for(Picture p: pictures){
                        if(pictureList.getSelectedValue().equals(p.getTitle())){
                            loadPictureImage(p.getFile());
                            new DBconsults(DBconection.getConnection()).updateVisits(p.getPictureId());
                        }
                    }
                }
            }
        });

        JPanel picturePanel = new JPanel();
        picturePanel.add(imageLabel);


        add(photographerPanel);
        add(datePanel);
        add(pictureScrollPanel);
        add(picturePanel);

        pack();
        setVisible(true);
    }

    private void loadPhotographersComboBox(){
        DBconsults consults = new DBconsults(DBconection.getConnection());
        List<String> photographerNames = consults.LoadPhotographers();

        for (String p: photographerNames){
            photographerComboBox.addItem(p);
        }
    }

    private void loadPictureList(String photographerName){
        DBconsults consults = new DBconsults(DBconection.getConnection());

        DefaultListModel<String> pictureTitles = new DefaultListModel<>();

        if(datePicker.getDate() != null){
            SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
            String newDate = formatDate.format(datePicker.getDate());

            pictures = consults.getPicturesByPhotographerAndDate(photographerName, newDate);
        }else{
            System.out.println(consults.getPicturesByPhotographer(photographerName));
            pictures = consults.getPicturesByPhotographer(photographerName);
        }

        for (Picture p: pictures){
            pictureTitles.addElement(p.getTitle());
        }
        this.pictureList.setModel(pictureTitles);
    }

    private void loadPictureImage(String imagePath){
        pictureImage = new ImageIcon(imagePath);
        Image image = pictureImage.getImage().getScaledInstance(250,250,Image.SCALE_SMOOTH);
        pictureImage = new ImageIcon(image);
        imageLabel.setIcon(pictureImage);
    }

    public static void main(String[] args) {
        new Window();

    }
}
