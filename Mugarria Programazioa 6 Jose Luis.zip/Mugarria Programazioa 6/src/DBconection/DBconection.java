package DBconection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconection {

        private static Connection conection;
        private static final String URL = "jdbc:mysql://192.168.1.47:3306/Mugarria6";
        private static final String USER = "joseluis";
        private static final String PASSWORD = "1";

    public DBconection(Connection connection) {
    }

    public static Connection getConnection(){
            try{
                conection = DriverManager.getConnection(URL,USER,PASSWORD);
                System.out.println("Conection sucessfull");

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            return conection;
        }
    }



