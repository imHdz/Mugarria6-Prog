package DBconsults;

import model.Photographer;
import model.Picture;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DBconsults {
    private Connection conection;

    public DBconsults(Connection connection){
        this.conection = connection;
    }

    /*
    este metodo devuelve una List de Strings la lista de String esta llena de nombres de fotografos, que conseguimos de la consulta
    select name from photograhpher
    */

    public List<String> LoadPhotographers(){
        List<String> photographerNames = new ArrayList<>();
        ResultSet result = null;
        String query = "SELECT name FROM Photographer" ;
        try(PreparedStatement st = conection.prepareStatement(query)){
            result = st.executeQuery();
            while(result.next()){
                photographerNames.add(result.getString("name"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return photographerNames;
    }

    /*
    Este metodo devuelve una lista de pictures, al selecionar toda la imagen tenemos que añadir todas y cada una de las columnas
    */
    public List<Picture> getPicturesByPhotographer(String photographerName){
        List<Picture> pictures = new ArrayList<>();
        ResultSet result = null;
        String query= "SELECT * FROM Picture WHERE photographerId = ?";
        try(PreparedStatement st = conection.prepareStatement(query)) {

            st.setInt(1, getPhotographerId(photographerName));
            System.out.println("DEBUG: PHOTOGRAPHER ID"+ getPhotographerId(photographerName));
            result = st.executeQuery();

            while(result.next()){
                int pictureId = result.getInt("pictureId");
                String title = result.getString("title");
                Date date_ = result.getDate("date");
                String file = result.getString("file");
                int visits = result.getInt("visits");
                int photographerId = result.getInt("photographerId");

                pictures.add(new Picture(pictureId,title,date_,file,visits,photographerId));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return pictures;
    }
    /*
    Este metodo devuelve una lista de pictures, al selecionar toda la imagen tenemos que añadir todas y cada una de las columnas, en este caso el resultado esta
    limitado por la fecha de datepicker y el id del fotografo
    */
    public List<Picture> getPicturesByPhotographerAndDate(String photographerName, String date){
        List<Picture> pictures = new ArrayList<>();
        ResultSet result = null;
        String query="SELECT * FROM Picture WHERE photographerId = ? AND date > ?";
        try(PreparedStatement st = conection.prepareStatement(query)) {
            st.setInt(1, getPhotographerId(photographerName));
            st.setString(2,date);
            result = st.executeQuery();

            while(result.next()){
                int pictureId = result.getInt("pictureId");
                String title = result.getString("title");
                Date date_ = result.getDate("date");
                String file = result.getString("file");
                int visits = result.getInt("visits");
                int photographerId = result.getInt("photographerId");


                pictures.add(new Picture(pictureId,title,date_,file,visits,photographerId));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return pictures;
    }

    /*
    metodo que devuelve int  recibe una String (el nombre de un fotografo) este lo utiliza despues para sustituirlo en la consulta, con este metodo conseguimos el
    id del fotografo utilizando su nombre
    */
    public int getPhotographerId(String photographerName){
        int photographerId = 0;
        ResultSet result = null;
        String query="SELECT photographerId FROM Photographer WHERE name = ?";
        try(PreparedStatement st = conection.prepareStatement(query)){
            st.setString(1, photographerName);
            result = st.executeQuery();

            if(result.next()){
                photographerId = result.getInt("photographerId");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return photographerId;
    }
 /*
 este metodo void accede a la tabla picture y updatea el apartado visits sumandole 1, a este metodo se accede clickando dos veces en el titulo de la foto, esta en WINDOW
  */
    public void updateVisits(int pictureId){
        String query="UPDATE Picture SET visits=(visits+1) WHERE pictureId = ?";
        try(PreparedStatement st = conection.prepareStatement(query)) {
            st.setInt(1, pictureId);
            int updated = st.executeUpdate();
            System.out.println(updated+ " sucessfully updated");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
