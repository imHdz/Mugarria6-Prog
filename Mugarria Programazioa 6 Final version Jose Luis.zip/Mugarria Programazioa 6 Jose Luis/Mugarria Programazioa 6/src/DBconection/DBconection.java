package DBconection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
/*
el ejecutable de la base de datos esta en la carpeta database SQL export
*/
public class DBconection {

        private static Connection conection;
        private static final String URL = "jdbc:mysql://localhost:3306/Mugarria6";
        private static final String USER = "root";
        private static final String PASSWORD = "zubiri";

        public DBconection(Connection connection) {

        }

        /*
        metodo para conectarse ala base de datos
         */
    public static Connection getConnection(){
            try{
                conection = DriverManager.getConnection(URL,USER,PASSWORD);
                System.out.println("Conection sucessfull");

            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
            return conection;
        }
    }



